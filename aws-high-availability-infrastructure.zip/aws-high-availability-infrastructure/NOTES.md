# Project Notes

This repository is intended as a portfolio/documentation version of the AWS environment.

Do not commit:
- AWS access keys
- secret keys
- private SSH keys
- `.pem` files
- passwords
- API tokens
- unredacted account credentials

The screenshots included in `screenshots/` have AWS resource/account identifiers redacted where appropriate.
